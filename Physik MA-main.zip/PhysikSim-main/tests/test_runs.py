import importlib.util
import pathlib
import numpy as np


def load_module(name):
    path = pathlib.Path(__file__).resolve().parents[1] / f"{name}.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


pendulum = load_module("pendulum")
pendulum3d = load_module("pendulum3d")
rk4_test1 = load_module("rk4_test1")
rk4_test2 = load_module("rk4_test2")
rk4_test3 = load_module("rk4_test3")


def test_pendulum_default():
    t, phi, omega, energy = pendulum.run(plot=False)
    # All returned arrays should have the same length
    assert t.shape == phi.shape == omega.shape == energy.shape
    # expected number of steps (10/h + 1)
    assert len(t) == 1001
    # initial conditions
    assert t[0] == 0
    assert np.isclose(phi[0], 0.1)
    # final time
    assert np.isclose(t[-1], 10)
    # final angle close to analytical small angle prediction
    expected_phi_end = 0.1 * np.cos(np.sqrt(9.81) * 10)
    assert np.isclose(phi[-1], expected_phi_end, atol=1e-3)
    # energy should stay positive
    assert energy[-1] > 0


def test_pendulum_energy_conservation():
    t, phi, omega, energy = pendulum.run(plot=False)
    # total mechanical energy should remain nearly constant
    assert np.max(np.abs(energy - energy[0])) < 1e-5


def test_pendulum3d_default():
    t, theta, phi, theta_dot, phi_dot, energy = pendulum3d.run(plot=False)
    assert t.shape == theta.shape == phi.shape == theta_dot.shape == phi_dot.shape == energy.shape
    assert len(t) == 1001
    assert np.isclose(theta[0], 0.1)
    assert np.isclose(phi[0], 0.0)
    expected_theta_end = 0.1 * np.cos(np.sqrt(9.81) * 10)
    assert np.isclose(theta[-1], expected_theta_end, atol=1e-3)


def test_pendulum3d_impulses_length():
    result = pendulum3d.run(force_x=0.5, force_y=-0.2, force_z=0.1, plot=False)
    t, theta, phi, theta_dot, phi_dot, energy = result
    assert t.shape == theta.shape == phi.shape == theta_dot.shape == phi_dot.shape == energy.shape
    assert len(t) == 1001


def test_pendulum3d_draw_and_arrows():
    result = pendulum3d.run(draw_mode=False, force_arrows=True, plot=False)
    t, theta, phi, theta_dot, phi_dot, energy = result
    assert t.shape == theta.shape == phi.shape == theta_dot.shape == phi_dot.shape == energy.shape


def test_pendulum3d_initial_phi_velocity():
    result = pendulum3d.run(phi_dot0=0.5, air_resistance=0.1, plot=False)
    _, _, phi, _, _, _ = result
    assert not np.isclose(phi[0], phi[-1])


def test_rk4_test1_default():
    t, x = rk4_test1.run(ax=None)
    assert len(t) == len(x) == 51
    assert t[0] == 0
    assert np.isclose(x[0], 1)
    assert np.isclose(t[-1], 5)
    assert np.isclose(x[-1], np.exp(t[-1]), atol=1e-3)


def test_rk4_test2_default():
    t, x = rk4_test2.run(ax=None)
    assert len(t) == len(x) == 51
    assert np.isclose(t[0], 0)
    assert np.isclose(x[0], 5)
    assert np.isclose(x[-1], t[-1] + 5)


def test_rk4_test3_default():
    t, x, y = rk4_test3.run(ax=None)
    assert t.shape == x.shape == y.shape
    assert len(t) == 1001
    assert np.isclose(t[0], 0)
    assert np.isclose(x[0], 5)
    assert np.isclose(y[0], 0)
    # check last step roughly matches analytical solution
    assert np.allclose([x[-1], y[-1]],
                       [5 * np.cos(t[-1]), -5 * np.sin(t[-1])],
                       atol=1e-6)
